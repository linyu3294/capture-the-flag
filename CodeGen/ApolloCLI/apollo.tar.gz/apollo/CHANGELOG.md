To see release notes and changes for `apollo`, See the [apollo-tooling changelog](https://github.com/apollographql/apollo-tooling/blob/master/CHANGELOG.md)
